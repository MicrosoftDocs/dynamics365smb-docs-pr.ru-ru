---
title: Creating additional sheets in Russia
description: Russian enhancements include additional sheets for VAT purchase ledgers and sales ledgers.
author: DianaMalina

ms.service: dynamics365-business-central
ms.topic: article
ms.search.keywords:
ms.date: 07/02/2019
ms.reviewer: edupont
ms.author: soalex
---
# How to: Create Additional Sheets

In [!INCLUDE[prodshort](../../includes/prodshort.md)], you can create additional sheets based on VAT purchase ledgers and VAT sales ledgers.

### To create entries for an additional sheet for a VAT purchase or sales ledger

1. Select the VAT purchase or sales line in the **VAT Ledger List** window with the required accounting period.

2. On the **Actions** tab, choose **Functions**, and then choose **Create Additional Sheet**.

3. Fill in the batch job according to the guidelines at Create VAT Sales Led. Ad. Sh..

   The parameters for creating a VAT purchase ledger additional sheet and VAT sales ledger additional sheet are the same as the parameters for creating the VAT Purchase Ledger and the VAT Sales Ledger.

### To print additional sheets on a VAT Ledger 

1. In the **VAT Purch. Ledger** or **VAT Sales Ledger**, on the **Actions** tab, choose **Options** tab.

2. Choose **Additional sheet**.

3. In the **Period Type** field, select one of the following options:

   - **Day**
   - **Month**
   - **Quarter**

   > :speech_balloon: Note
   >
   > In the **VAT Ledger** tab, the **Type** field and the **Code** field are automatically created.

4. Choose **Preview** or choose **Print**.

## Creating Corrective Documents to Include in Additional Sheets

The information changed in the tax invoice after the invoice is registered in the previous purchase book must be reflected in the additional sheet of the previous book (corrected book). The additional sheet is part of the purchase book.

The first line contains the totals of the purchase book at the end of the period when the tax invoice is registered. The next lines are the annulled tax invoices. The annulled tax invoices have a negative sign if the corrected invoice amount is lesser than the initial amount, and a positive sign if the corrected invoice amount is greater than the initial amount. The last line is calculated as the sum of the amounts of the first total line and the annulled tax invoices.

The information changed in the tax invoice after the invoice is registered in the previous sales book must be reflected in the additional sheet of the previous book (corrected book). The additional sheet is part of the sales book.

The first line contains totals of the sales book at the end of the period when the tax invoice is registered. The next lines are the annulled tax invoices with a negative sign. The corrected invoices with positive amounts belong to the previous period. The last line is calculated as the sum of the amounts of the first total line, annulled tax invoices, and the corrected invoices.

Processing of corrective documents for sales book is similar to processing for purchases book with one difference. In additional sheets, the number and the date of initial factura must be reflected.

#### To create a correction entry for posted purchase credit memos

1. Create and post a purchase credit memo.
2. Choose the **VAT** tab.
3. Select the **Additional VAT Ledger Sheet** field.
4. Enter information in the following fields:
   - **Corrected Document Date**
   - **Vendor VAT Invoice Date**
   - **Vendor VAT Invoice Rcvd Date**
   - **Vendor VAT Invoice No.**

#### To create a correction entry for a posted purchase invoice

1. Create and post a purchase invoice.

2. Choose the **VAT** tab.

3. Select the **Corrected Document Date** field.

4. Enter information in the following fields:

   - **Vendor VAT Invoice Date**
   - **Vendor VAT Invoice Rcvd. Date**
   - **Vendor VAT Invoice No.**

   > :speech_balloon: Note
   >
   > You can also create corrective documents in the general journal. General journal lines contain all the fields mentioned above.

#### To post additional VAT

1. In the **Sales Invoice** window or the **Credit Memo** window, choose the **VAT** tab.

2. Enter the **Posting No.** field.

   > :speech_balloon: Note
   >
   > You cannot post an invoice with the same number as the initial invoice. You must use an extra symbol in addition to the initial number.

3. Select the **Additional VAT Ledger Sheet** field.

4. Enter information in the **Corrected Document Date** field.

5. In the additional sheet, the **Date of Facture** field reflects the corrected document date.

## See Also

[VAT Ledgers](VAT-Ledgers.md)
