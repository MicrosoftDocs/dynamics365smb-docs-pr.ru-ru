---
title: Human resources in Russia
description: Russian enhancements include a human resources module.
author: DianaMalina

ms.service: dynamics365-business-central
ms.topic: article
ms.search.keywords:
ms.date: 07/02/2019
ms.reviewer: edupont
ms.author: soalex
---

# Human Resources

In This Section:

[Payroll](Payroll.md)

[Establishment of charges and deductions to the employee](Establishment-of-charges-and-deductions-to-the-employee.md)

[Absence registration](Absence-registration.md)

[Dismissal](Dismissal.md)

[Forming and changing Staff List Order, Staff Arrangement](Forming-and-changing-Staff-List-Order-Staff-Arrangement.md)

[Vacation planning](Vacation-planning.md)
