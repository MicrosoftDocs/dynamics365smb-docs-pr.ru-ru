# Запасы

 Функция запасов для России описывается в нескольких разделах.

 

## В этом разделе

 

[Настройка товаров](https://github.com/DianaMalina/dynamics365smb-docs/blob/live/business-central/LocalFunctionality/Russia/inventory-setup.md)

[Акты Оприходования](https://github.com/DianaMalina/dynamics365smb-docs/blob/live/business-central/LocalFunctionality/Russia/item-documents.md)

[Акты обязательств по товару](https://github.com/DianaMalina/dynamics365smb-docs/blob/live/business-central/LocalFunctionality/Russia/item-obligatory-acts.md)

[Акт инвентаризации расчетов с клиентами и платежей ИНВ-17](https://github.com/DianaMalina/dynamics365smb-docs/blob/live/business-central/LocalFunctionality/Russia/inventory-act-of-receivables-and-payables-inv-17.md)

[Финансовый оборот для товара](https://github.com/DianaMalina/dynamics365smb-docs/blob/live/business-central/LocalFunctionality/Russia/item-general-ledger-turnover.md)

[Практическое руководство. Создание товарного отчета ТОРГ-29](https://github.com/DianaMalina/dynamics365smb-docs/blob/live/business-central/LocalFunctionality/Russia/how-to-create-the-torg-29-goods-report.md)

