# Практическое руководство. Просмотр учтенных операций по издержкам основных средств

Для каждого кода издержек ОС можно просмотреть все учтенные операции основных средств. Ниже показано, как просмотреть учтенные операции.

 

## Просмотр учтенных операций по издержкам основных средств 

- Выберите значок ![Поиск страницы или отчета](https://github.com/DianaMalina/dynamics365smb-docs/blob/live/business-central/LocalFunctionality/Russia/1.png), введите **Книга операций по ОС**, а затем выберите связанную ссылку.

 

## См. также

[Практическое руководство. Создание издержек ОС](https://github.com/DianaMalina/dynamics365smb-docs/blob/live/business-central/LocalFunctionality/Russia/how-to-create-a-fixed-asset-charge.md)
